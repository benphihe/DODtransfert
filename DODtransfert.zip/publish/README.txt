==========================================
DOD Transfert - Guide d'installation
==========================================

FICHIER EXÉCUTABLE:
-------------------
DODtransfert.Client.exe - Double-cliquez sur ce fichier pour lancer l'application

REQUIS:
-------
- Windows 10 ou supérieur
- Aucune installation supplémentaire nécessaire (tout est inclus)

UTILISATION:
------------
1. Double-cliquez sur DODtransfert.Client.exe
2. Entrez un nom d'utilisateur et cliquez sur "Se connecter"
3. Pour démarrer un serveur : Cliquez sur "Démarrer serveur"
4. Pour vous connecter à un serveur : Entrez l'adresse IP et cliquez sur "Se connecter"

TRANSFERT DE FICHIERS:
---------------------
- Menu "Transfert" : Transfert normal de fichiers (photos et PDF)
- Menu "Ajout de produits" : Transfert avec validation (marque, produit, photos, PDF)

FICHIERS REÇUS:
--------------
Les fichiers reçus sont sauvegardés dans :
C:\Users\[VotreNom]\Downloads\DODtransfert\

RÉSEAU:
-------
- Port par défaut : 8888
- Assurez-vous que le pare-feu Windows autorise l'application
- Les machines doivent être sur le même réseau local

SUPPORT:
--------
Pour toute question, contactez l'administrateur système.
